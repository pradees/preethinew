package com.insurance.claim.service;

import com.insurance.claim.bean.CreateClaimBean;
import com.insurance.claim.dao.CreateClaimDAO;

public class CreateClaimService {

	public int createClaim(CreateClaimBean claimbean,String str) {
    CreateClaimDAO DAOobj=new CreateClaimDAO();
    
    int updateResult = 0;
	 try
	 {
		 updateResult = DAOobj.createClaim(claimbean,str);
		 System.out.println("service : "+updateResult);
		 return updateResult;
	 }
	 catch(Exception ex)
	 {
		 System.out.println(ex.toString());
		 return 0;
	 }
	}

	
	
}
