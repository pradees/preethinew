package com.insurance.claim;

//import java.beans.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.insurance.claim.bean.UserNameBean;



public class LoginPage extends  HttpServlet
{
	String str=null;
	RequestDispatcher rd=null;
	Connection con=null;

	ResultSet rs=null;
	ResultSet rs1=null;
	public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		UserNameBean userbean=new UserNameBean();
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		int update=0;
		try {	      
			
	     con=Connect.getconnect();
	     
		 String uname=request.getParameter("userName");
		 String password=request.getParameter("userPwd");
		
		 userbean.setUsername(uname);
		 HttpSession session=request.getSession();
		 session.setAttribute("user", uname);
		 String sql="select Role_Code from User_Role where User_name='"+uname+"' and Password='"+password+"'";
		 
		 Statement stmt=con.createStatement();
			update=stmt.executeUpdate(sql);
			rs=stmt.executeQuery(sql);
		//update=pst.executeUpdate();
		System.out.println("sql : "+update);
		if(update==1) {
		 while(rs.next())
		 {
			 str=rs.getString(1); 
			 HttpSession session4=request.getSession();
			 session4.setAttribute("role", str);
			 //System.out.println(str);
			 
		 }}
		else
			str="z";
		 
		System.out.println("Str = "+str);
		 if(str.equals("Admin") && update==1)
			 {
			 request.getRequestDispatcher("/admin.jsp").include(request, response);
		     }
		 else if(str.equals("Agent")  && update==1)
		   {
			 String agcode=null;
			 String sql1="select Agent_Code from User_Role where User_name='"+uname+"' ";
			 Statement stmt1=con.createStatement();
			 int i=stmt.executeUpdate(sql1);
			 System.out.println("sql1 : "+i);
			rs1=stmt.executeQuery(sql1);
			 
			 while(rs1.next())
			 {
				 agcode=rs1.getString(1);
				 
				 HttpSession session6=request.getSession();
				 session6.setAttribute("agcode", agcode); 
			 }
			 System.out.println("Retrived agcode : "+agcode);
			 
			 request.getRequestDispatcher("/agent.jsp").include(request, response);
		    }
		 else if(str.equals("Insured")  && update==1)
		    {
			 request.getRequestDispatcher("/user.jsp").include(request, response);
		    }
		 else if(update==0)
		 {
			 request.getRequestDispatcher("/invalidlogin.jsp").include(request, response);
		 }
		
		 }
		 
	
		 catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}
}
