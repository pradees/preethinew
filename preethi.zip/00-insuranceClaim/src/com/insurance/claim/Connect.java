package com.insurance.claim;

import java.sql.Connection;
import java.sql.DriverManager;

public class Connect
{
	

		public static Connection getconnect()

	{
			Connection connect=null;

			try
			{
		     Class.forName("oracle.jdbc.driver.OracleDriver");
			connect=DriverManager.getConnection("jdbc:oracle:thin"+":@10.219.34.3:1521/orcl","trg624","training624");
		    System.out.println("connected");
			}
			
			catch(Exception e)
			{
				System.out.println(e);
			}
			return connect;
	}
		
}

