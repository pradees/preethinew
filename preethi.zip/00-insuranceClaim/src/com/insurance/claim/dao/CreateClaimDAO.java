package com.insurance.claim.dao;

	import java.io.IOException;
	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;

	import javax.servlet.RequestDispatcher;
	import javax.servlet.ServletException;
	import javax.servlet.http.HttpServlet;
	import javax.servlet.http.HttpServletRequest;
	import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.insurance.claim.Connect;
import com.insurance.claim.bean.CreateClaimBean;
import com.insurance.claim.bean.UserNameBean;
	public class CreateClaimDAO {

		public int createClaim(CreateClaimBean claimbean,String str) {
			UserNameBean userbean=new UserNameBean();
			int updateResult=0;
			ResultSet rs=null,rs1=null,rs2=null;
			Connection con = null;
			  PreparedStatement pst = null,ps1=null,ps2=null;
			  
			  int seq=0,seq1=0;
			  try {
				  
	con=DB.getConnection();
    String sql="insert into Claim values(claimnumber_seq.nextval,?,?,?,?,?,?,policynumber_seq.nextval)";
    
    
		//policynumber_seq.nextval
		pst=con.prepareStatement(sql);
		pst.setString(1,claimbean.getReason());
		pst.setString(2,claimbean.getLocation());
		pst.setString(3,claimbean.getCity());
		pst.setString(4,claimbean.getState());
		pst.setInt(5,claimbean.getZip());
		pst.setString(6,claimbean.getType());
				
		//rs=pst.executeQuery();
		
		updateResult=pst.executeUpdate();
			
		System.out.println("dao : "+updateResult);
		
		String sql1="select claimnumber_seq.currval from dual";
		String sql2="select policynumber_seq.currval from dual";
		ps1=con.prepareStatement(sql1);
		rs1=ps1.executeQuery();
		while(rs1.next())
		{
			 seq=rs1.getInt(1);
		}
		ps1=con.prepareStatement(sql2);
		rs2=ps1.executeQuery();
		while(rs2.next())
		{
			 seq1=rs2.getInt(1);
		}
		
		/*HttpSession session=request.getSession(true);
		 session.setAttribute("policynumber", seq1);*/
		
		String sql4="insert into view_claim values(?,?,?,?)";
		ps2=con.prepareStatement(sql4);
		ps2.setString(1,str);
		ps2.setInt(2,seq);
		ps2.setInt(3, seq1);
		ps2.setString(4, claimbean.getType());
		ps2.executeUpdate();
		//System.out.println(str+"ready to update");
		return updateResult;
				
		  }
		 catch (Exception e)
			{ System.out.println(e);
			return updateResult;
			}
	
			
		}	
	}
	
	
	
	/*public void doGet(HttpServletRequest request,HttpServletResponse response)throws ServletException,IOException
	{
		public int createClaim(CreateClaimBean claimbean) {
			
		response.setContentType("text/html");
		RequestDispatcher rd=null;
		Connection con=null;
		PreparedStatement pst=null;
		ResultSet rs=null;
		String str=null;
		
		try {
			con=Connect.getconnect();
			
			String reason=request.getParameter("reason");
			 String location=request.getParameter("location");
			 String city=request.getParameter("city");
			 String state=request.getParameter("state");
			 int zip=Integer.parseInt(request.getParameter("zip"));
			 String type=request.getParameter("type");
			
			 String sql="insert into Claim values(claimnumber_seq.nextval,?,?,?,?,?,?,policynumber_seq.nextval)";
			 //policynumber_seq.nextval
			 pst=con.prepareStatement(sql);
				pst.setString(1,reason);
				pst.setString(2,location);
				pst.setString(3,city);
				pst.setString(4,state);
				pst.setInt(5,zip);
				pst.setString(6,type);
				
				rs=pst.executeQuery();
				int result=pst.executeUpdate();
				System.out.println(result);
				//int num=pst.executeQuery();
				System.out.println("added the claim details");
				if(result==1)
				{
					return result;
					request.getRequestDispatcher("/ClaimDisplay.jsp").include(request, response);
				}
			
		}
		catch (Exception e)
		{ System.out.println(e);}
		
		
		}
		
	*/







